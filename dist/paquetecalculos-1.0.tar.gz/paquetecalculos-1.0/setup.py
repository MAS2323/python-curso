#
from setuptools import setup

setup(
    name="Paquetecalculos",
    version="1.0",
    description="Paquetes de redondeo y potencia",
    author="Mas Onewe",
    author_email="masoneweernesto@gmail.com",
    url="www.programacion.com",
    packages=["calculos", "calculos.redondeo_potencia"]
)
