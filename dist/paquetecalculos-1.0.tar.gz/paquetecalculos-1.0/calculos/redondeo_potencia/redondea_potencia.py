def potencia(base, exponete):
    print("El resultado de la potencia es: ", base**exponete)


def redondear(numero):
    print("El resultado de la suma es: ", round(numero))
