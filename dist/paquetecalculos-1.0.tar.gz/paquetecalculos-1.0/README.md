#Introduccion a Python
<p>
Python es un lenguaje de programación potente y fácil de aprender. Tiene estructuras de datos de alto nivel eficientes y un simple pero efectivo sistema de programación orientado a objetos. 
</p>

```
las instrucciones en python siempre van en una sola linea: 
tambien podemos utilizar el punto y coma (;) para separar dos instrucciones, pero es una practica no recomendable 
print(" Hola alumnos")
print("Hola alunmos"); print("Adios mundo cruel")
```

<p>
Los comentarios simples o de una sola linea en python se introducen utilizando el singno
de #
#Comentario simple 

mientras que los comentarios multiples se utiliza las triple comillas

"""
comentario multiple 
"""
</p>
## Las variables en python 
<p>
Hay muchos tipos de variables, pero en python las variables se asignan 
mi_nomnre = "Me llamo Ernesto"
print(mi_nombre)
</p>
